package m3.uf4.pt1.fitxers;

public interface Imprimible {
	public static final int AMPLE_IDENT = 5;
	public static final int AMPLE_GAP = 2;
	public static final int AMPLE_MIDA = 9;
	public static final int AMPLE_DATA = 16;
	public static final int AMPLE_NOM = 20;

	public String imprimir(char unitats);
}
